ibus-daemon -xdr
ibus engine Bamboo
